# Usage

Set the following repo secrets, then trigger `Register APP` workflow manually. Read <https://sl.al/ABzD> for more details.

| Name   | Value                                                   |
| ------ | ------------------------------------------------------- |
| PAT    | Github personal access token with `workflow` permission |
| USER   | E5 admin emails line seperated                          |
| PASSWD | E5 admin passwords line seperated                       |
